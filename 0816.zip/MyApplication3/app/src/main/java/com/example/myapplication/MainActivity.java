package com.example.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }
    int i=0 ;

    public void plus2(View v){
        TextView hello;
        hello = findViewById(R.id.textView);
        i=i+2;
        hello.setText("" + i );

        TextView text;
        text = findViewById(R.id.textView3);
        text.append("2分進\n");
    }
    public void plus3(View v){
        TextView hello;
        hello = findViewById(R.id.textView);
        i=i+3;
        hello.setText("" + i );

        TextView text;
        text = findViewById(R.id.textView3);
        text.append("3分進\n");
    }

}
